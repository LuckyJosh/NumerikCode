% Skript zum Testen der der Implementierung der Funktionen 
% LU_decompose, forward_solve und backward_solve

% Erstellen von 5 Zufallsmatrizen, verschiedener Dimension
M = cell(1,5);
for i = 1:5
   M{i} = rand(2+i) * ceil(rand(1)*10);
end

% Zuf�llige rechte Seiten des Gleichungsystems, mit �bereinstimmender
% Dimension
b = cell(1,5);
for i = 1:5
   b{i} = rand(2+i,1) * ceil(rand(1)*10);
end

% Berechnung der L�sung des Gleichungssystems Mx = b durch die 
% LU-Zerlegung => x und dem MATLAB "\" Operator => X 
x = cell(1,5);
X = cell(1,5);
for i = 1:5
    LU = LU_decompose(M{i});
    x{i} = backward_solve(LU, forward_solve(LU, b{i}));
    X{i} = M{i}\b{i};
end    

% Ausgabe der Ergebnisse
for i = 1:5
    fprintf('%i. Matrix des LGS\n', i);
    disp(M{i});
    fprintf('\n%i. Rechte Seite des LGS\n', i);
    disp(b{i});
    fprintf('\n%i. Ergebnis der LU-Zerlegung:\n',i);
    disp(x{i});
    fprintf('\n%i. Ergbnis mit M\\b:\n', i);
    disp(X{i});
end